#!/usr/bin/env python3
"""Qualified LLVM/libomp/Archer diagnostics; no blanket sanitizer PASS."""
import json
import os
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode=True
import run as h

h.OUT=h.ROOT/'validation/local'/sys.argv[1]
h.OUT.mkdir(exist_ok=False)
summary={'status':'FAIL','source_sha':h.sha(h.ROOT/'src/a249107.c'),
         'make_sha':h.sha(h.ROOT/'src/Makefile')}
try:
    paths=list(Path('/usr/lib').glob('llvm-*/lib/libarcher.so'))
    archer=next(p for p in paths if 'llvm-18' in str(p))
    flags='-O1 -g -std=c17 -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Werror -fopenmp=libomp -fsanitize=thread -fno-omit-frame-pointer'
    env=dict(h.ENV,OMP_TOOL='enabled',OMP_TOOL_LIBRARIES=str(archer),
             TSAN_OPTIONS='ignore_noninstrumented_modules=1:halt_on_error=1:exitcode=66')
    summary.update(archer_path=str(archer),archer_sha=h.sha(archer),flags=flags,
                   environment={k:env[k] for k in ('OMP_TOOL','OMP_TOOL_LIBRARIES','TSAN_OPTIONS')})
    control=h.OUT/'controls'
    h.call(['clang-18',*flags.split(),h.ROOT/'validation/tsan_controls.c','-o',control])
    startup=h.call([control,'startup'],env=env)
    clean=h.call([control,'clean'],env=env)
    h.oracle.need('WARNING' not in clean.stderr,'race-free control noise')
    race=h.call([control,'race'],expected=66,env=env)
    h.oracle.need('data race' in race.stderr and 'tsan_controls.c:' in race.stderr,
                  'source-located deliberate race not detected')
    exe=h.build('build',cc='clang-18',flags=flags,link='-fopenmp=libomp -fsanitize=thread')
    for name,lo,hi,t,group in [('one',2,33000,1,3),('four',2,33000,4,3),
                             ('eight',2,33000,8,2),('positive',1058578125,1058578125,8,1)]:
        run=h.init(name,lo,hi,exe,threads=t,group=group,env=env)
        found=h.finish(run,exe,env=env)
        expected=[w for n in range(lo,hi+1) if (w:=h.oracle.witness(n))]
        h.oracle.need(found==expected,'TSan oracle mismatch')
    h.oracle.need(all('WARNING: ThreadSanitizer' not in e.get('stderr','')
                     for e in h.EVENTS if e.get('expected')==0),'candidate report')
    summary.update(status='E / PASS',tested_binary_sha=h.sha(exe),
                   qualification='startup; silent synchronized control; source race detected; candidate silent')
except (StopIteration,FileNotFoundError) as e:
    summary.update(status='N/A',reason=str(e))
except ValueError as e:
    stderr=h.EVENTS[-1].get('stderr','')
    if 'unexpected memory mapping' in stderr or 'personality' in stderr or 'ADDR_NO_RANDOMIZE' in stderr:
        summary.update(status='N/A',reason='TSan launch/shadow-memory environment: '+stderr)
    else:
        summary.update(status='INCONCLUSIVE',reason=str(e))
    raise
finally:
    (h.OUT/'events.json').write_text(json.dumps(h.EVENTS,indent=2)+'\n')
    (h.OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
