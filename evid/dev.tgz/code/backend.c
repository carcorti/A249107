/* White-box backend probes; not an independent implementation or campaign. */
#define main included_program_main
#include "../src/a249107.c"
#undef main
#define CK(c) do { if(!(c)) die("backend probe: " #c); } while(0)
int main(int argc,char **argv) {
    uint64_t u=0; u128 w=0; char text[40]; bool fb=false;
    if(argc==3 && !strcmp(argv[1],"prime")) {
        CK(dec64(argv[2],&u)); printf("%d\n",prime64(u)); return 0;
    }
    if(argc==3 && !strcmp(argv[1],"roundtrip")) {
        Config c={.start=4031,.end=4031,.block=16384,.group=1,.threads=1};
        memset(c.cfg_hash,'0',64); c.cfg_hash[64]=0;
        Hit h={.n=4031,.x1=MAX_D1,.x2=MAX_D2,.x3=MAX_D3,
               .x4=MAX_D4,.x5=MAX_D5,.root=MAX_ROOT};
        Segment a={.id=0,.low=4031,.high=4031,.frontier=4031,
                   .elapsed_ns=UINT64_MAX,.hits=&h,.nhit=1,.cap=1}, b={0};
        write_seg(argv[2],&c,&a);
        CK(read_seg(argv[2],&c,0,&b));
        CK(b.nhit==1 && b.elapsed_ns==UINT64_MAX && b.hits[0].n==4031 &&
           b.hits[0].x1==h.x1 && b.hits[0].x2==h.x2 && b.hits[0].x3==h.x3 &&
           b.hits[0].x4==h.x4 && b.hits[0].x5==h.x5 && b.hits[0].root==h.root);
        free_seg(&b); puts("SYNTHETIC WIDTH ROUNDTRIP PASS (not a witness)"); return 0;
    }
    CK(argc==1);
    CK(dec64("18446744073709551615",&u) && u==UINT64_MAX);
    CK(!dec64("18446744073709551616",&u) && !dec64("-1",&u));
    CK(dec128("340282366920938463463374607431768211455",&w) && w==~(u128)0);
    CK(!dec128("340282366920938463463374607431768211456",&w));
    fmt128(~(u128)0,text); CK(!strcmp(text,"340282366920938463463374607431768211455"));
    CK(isqrt64(0)==0 && isqrt64(UINT64_MAX)==UINT32_MAX);
    CK(gcd64(10403,101)==101);
    CK(rho_step(UINT64_MAX-2,32,UINT64_MAX)==36);
    mpz_t z,q,r,t; mpz_inits(z,q,r,t,NULL);
    mpz_set128(z,~(u128)0); CK(mpz_get128_checked(z,&w) && w==~(u128)0);
    mpz_add_ui(z,z,1); CK(!mpz_get128_checked(z,&w));
    mpz_set_si(z,-1); CK(!mpz_get128_checked(z,&w));
    const u128 bounds[]={CAP,MAX_D1,MAX_D2,MAX_D3,MAX_D4,MAX_D5};
    for(unsigned j=0;j<6;++j) {
        mpz_set128(z,bounds[j]); mpz_mul(z,z,z); mpz_add(q,q,z);
    }
    CK(mpz_sizeinbase(q,2)==138);
    mpz_sqrt(r,q); CK(mpz_get128_checked(r,&w) && w==MAX_ROOT);
    mpz_mul(t,r,r); CK(mpz_cmp(t,q)<=0);
    mpz_add_ui(r,r,1); mpz_mul(t,r,r); CK(mpz_cmp(t,q)>0);
    mpz_clears(z,q,r,t,NULL);
    for(uint64_t n=0;n<=10000;++n) {
        CK(derivative64(n,&w,&fb)); fmt128(w,text);
        printf("D\t%" PRIu64 "\t%s\t%d\n",n,text,prime64(n));
    }
    const uint64_t cases[]={73,193,14089,407521,299210837,
        UINT64_C(341550071728321),UINT64_C(3825123056546413051),
        UINT64_C(18446744073709551557),UINT64_MAX,
        UINT64_C(18446744030759878681),UINT64_C(17562825000000000000)};
    for(size_t i=0;i<sizeof cases/sizeof cases[0];++i) {
        uint64_t n=cases[i]; fb=false;
#ifdef A249107_FORCE_FALLBACK
        if(n>UINT64_C(1000000000000)) continue;
#endif
        CK(derivative64(n,&w,&fb)); fmt128(w,text);
        printf("D\t%" PRIu64 "\t%s\t%d\n",n,text,prime64(n));
    }
    fb=false; uint64_t factor=split64(10403,&fb);
    CK(factor==101 || factor==103);
#ifdef A249107_FORCE_FALLBACK
    CK(fb && factor==101);
#endif
    Hit hit; CK(predicate(8,12,&hit,&fb)==0); /* chain 8,12,16,32,80,176 */
    CK(predicate(13,1,&hit,&fb)==0); /* 13,1,0,0,0,0 */
    CK(predicate(1,1,&hit,&fb)==-1);
    atomic_store(&stopped,1);
    CK(predicate(4031,168,&hit,&fb)==-1);
    CK(!derivative64(10403,&w,&fb));
    atomic_store(&stopped,0);
    live_enabled=true; live_begin=ns_now();
    live_target=CAP; live_segment=7; live_frontier=4030; active_input=4031;
    atomic_store(&next_note,0); heartbeat(14089); live_enabled=false;
    Config c={.start=2,.end=CAP,.block=1048576,.group=20000,.threads=8};
    uint64_t previous=1,count=num_segments(&c);
    for(uint64_t j=0;j<count;++j) {
        uint64_t lo,hi; seg_bounds(&c,j,&lo,&hi);
        CK(lo==previous+1 && lo<=hi && (hi-lo)/c.block+1<=c.group);
        previous=hi;
    }
    CK(previous==CAP);
    printf("BACKEND PASS segments=%" PRIu64 " forced=%d\n",count,
#ifdef A249107_FORCE_FALLBACK
           1
#else
           0
#endif
    );
    return ferror(stdout)?1:0;
}
