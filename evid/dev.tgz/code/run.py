#!/usr/bin/env python3
"""Bounded development evidence, never an official contiguous extension.

One matrix per exact identity; reports commands, bytes, counts, outputs, times.
Use a fresh output basename. No assertions implement the independent oracle.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
sys.dont_write_bytecode = True
import check as oracle

ROOT = Path(__file__).resolve().parents[1]
EVENTS = []
OUT = None
ENV = dict(os.environ, OMP_DYNAMIC='FALSE')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def call(args, expected=0, timeout=60, env=None):
    args = [str(x) for x in args]
    begin = time.monotonic()
    result = subprocess.run(args, capture_output=True, text=True,
                            timeout=timeout, env=env or ENV)
    EVENTS.append(dict(args=args, returncode=result.returncode, expected=expected,
                       wall_seconds=time.monotonic()-begin,
                       stdout=result.stdout, stderr=result.stderr))
    oracle.need(result.returncode == expected, 'command failed: '+str(args))
    return result


def build(name, cc='gcc', flags=None, link=None, backend=False, extra=()):
    dest = OUT/name
    (dest/'src').mkdir(parents=True)
    for n in ('a249107.c', 'Makefile'):
        shutil.copyfile(ROOT/'src'/n, dest/'src'/n)
    flags = flags or '-O3 -std=c17 -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wdouble-promotion -Wformat=2 -Werror -fopenmp'
    if backend:
        (dest/'validation').mkdir()
        shutil.copyfile(ROOT/'validation/backend.c', dest/'validation/backend.c')
        exe = dest/'backend'
        binds = ['-DA249107_SOURCE_SHA="'+sha(ROOT/'src/a249107.c')+'"',
                 '-DA249107_MAKE_SHA="'+sha(ROOT/'src/Makefile')+'"']
        call([cc, *flags.split(), *binds, *extra, dest/'validation/backend.c',
              '-o', exe, *(link or '-fopenmp').split(), '-lgmp', '-lcrypto'])
    else:
        call(['make', '-C', dest/'src', 'CC='+cc, 'CFLAGS='+flags,
              'LDFLAGS='+(link or '-fopenmp')])
        exe = dest/'src/a249107'
    EVENTS.append(dict(binary=str(exe), binary_sha=sha(exe), compiler=cc,
                       cflags=flags, link=link or '-fopenmp'))
    return exe


def init(name, lo, hi, exe, threads=8, group=None, block=16384, env=None):
    run = OUT/name
    blocks = (hi-lo+block)//block
    call([exe, 'init', run, lo, hi, block, group or blocks, threads], env=env)
    return run


def finish(run, exe, env=None):
    c = oracle.config((run/'run.cfg').read_bytes())
    for _ in range(oracle.segments(c)):
        call([exe, 'next', run], env=env)
    call([exe, 'verify', run], env=env)
    return oracle.sealed_run(run)[1]


def backend(name, extra=(), cc='gcc', flags=None, link=None, env=None):
    exe = build(name, cc, flags, link, backend=True, extra=extra)
    result = call([exe], env=env)
    count = 0
    import sympy
    for line in result.stdout.splitlines():
        if not line.startswith('D\t'):
            continue
        _, n, d, prime = line.split('\t')
        n = int(n)
        factors = sympy.factorint(n) if n >= 2 else {}
        expected = sum(int(e)*(n//int(p)) for p, e in factors.items())
        oracle.need(int(d) == expected and int(prime) == int(sympy.isprime(n)),
                    'backend independent factor/primality mismatch')
        if n <= 10000:
            oracle.need(int(d) == oracle.derivative(n), 'trial backend mismatch')
        count += 1
    oracle.need(count >= 10001 and 'BACKEND PASS' in result.stdout, 'backend coverage')
    return count


def smoke(exe):
    run = init('smoke', 2, 5000, exe, threads=4)
    found = finish(run, exe)
    expected = [w for n in range(2, 5001) if (w := oracle.witness(n))]
    oracle.need(found == expected, 'smoke complete independent interval')
    return run


def clone(run, name):
    dest = OUT/name
    shutil.copytree(run, dest)
    return dest


def rejected(exe, args, expected=1):
    call([exe, *args], expected=expected)


def matrix():
    exe = ROOT/'src/a249107'
    baseline = smoke(exe)
    windows = [(10807,10839), (380264115,380264147), (1058578109,1058578141)]
    for j, (lo, hi) in enumerate(windows):
        run = init('window'+str(j), lo, hi, exe, threads=(1,4,8)[j])
        found = finish(run, exe)
        oracle.need(found == [w for n in range(lo,hi+1) if (w := oracle.witness(n))],
                    'complete independent high window')
    seeds = [int(line.split()[1]) for line in (ROOT/'data/b249107.txt').read_text().splitlines() if line]
    for j,n in enumerate(seeds+[1774631673,30429212500,205397184375,
                                278971073535,8019124783964,23772822265625]):
        run = init('positive'+str(j), n, n, exe)
        oracle.need(finish(run,exe) == [oracle.witness(n)], 'isolated positive replay')
    # Numeric endpoint execution is a tiny disjoint diagnostic, never full coverage.
    run = init('cap', oracle.CAP-3, oracle.CAP, exe)
    cap_hits = finish(run,exe)
    oracle.need(cap_hits == [w for n in range(oracle.CAP-3,oracle.CAP+1)
                            if (w := oracle.witness(n))], 'cap window')
    variants=[]
    for t,g in [(1,5),(4,2),(8,1)]:
        run=init('partition'+str(t),2,65538,exe,threads=t,group=g)
        variants.append(finish(run,exe))
    oracle.need(variants[0] == variants[1] == variants[2], 'partition/thread disagreement')
    # Retain exact checkpoint after cooperative termination, then resume it.
    run=init('interrupt',380264132,380526275,exe,threads=4,group=16)
    log=OUT/'interrupt.stderr'
    with log.open('w') as f:
        begin=time.monotonic()
        p=subprocess.Popen([str(exe),'next',str(run)],stdout=subprocess.PIPE,stderr=f,env=ENV,text=True)
        state=run/'s0000000000.tsv'
        while p.poll() is None and not state.exists() and time.monotonic()-begin<30:
            time.sleep(.01)
        oracle.need(p.poll() is None and state.exists(), 'interruption fixture did not reach checkpoint')
        p.send_signal(signal.SIGTERM)
        stdout,_=p.communicate(timeout=30)
    EVENTS.append(dict(args=[str(exe),'next',str(run),'SIGTERM after first checkpoint'],
                       returncode=p.returncode,expected=2,wall_seconds=time.monotonic()-begin,
                       stdout=stdout,stderr=log.read_text()))
    oracle.need(p.returncode==2,'cooperative stop exit')
    partial=state.read_text()
    frontier=int(next(x.split('\t')[1] for x in partial.splitlines() if x.startswith('frontier\t')))
    oracle.need(380264131<frontier<380526275 and (frontier-380264131)%16384==0,
                'stop did not retain whole completed blocks')
    rejected(exe,['verify',run],2)
    finish(run,exe)
    # Existing directory, lock ownership, parser widths and artifact count fail closed.
    rejected(exe,['init',baseline,2,5000,16384,1,4])
    with (baseline/'run.cfg').open() as f:
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        rejected(exe,['status',baseline])
    for j,args in enumerate([(1,2,16384,1,1),(2,oracle.CAP+1,16384,1,1),
                             (2,3,16383,1,1),(2,3,16384,0,1),(2,3,16384,1,9),
                             (2,oracle.CAP,16384,1,8),
                             ('18446744073709551616',3,16384,1,1)]):
        rejected(exe,['init',OUT/('badcli'+str(j)),*args])
    for name,raw in [('nul',b'\0'),('truncated',b'x'),('oversized',b'x'*256+b'\n'),
                     ('cr',b'\r\n')]:
        bad=clone(baseline,'config-'+name)
        with (bad/'run.cfg').open('ab') as f: f.write(raw)
        rejected(exe,['verify',bad])
    for name in ('manifest.tsv','hits.tsv','s0000000000.tsv','s0000000000.sha256'):
        bad=clone(baseline,'corrupt-'+name)
        raw=(bad/name).read_bytes()
        (bad/name).write_bytes(raw[:-1]+b'x\n')
        rejected(exe,['verify',bad])
        rejected(exe,['next',bad])
    bad=clone(baseline,'orphan')
    (bad/'s0000000001.sha256').write_text('0'*64+'\n')
    rejected(exe,['verify',bad])
    # Authoritative seals repair valid truncated aggregate prefixes, not changed data.
    repaired=clone(baseline,'repair')
    for n in ('manifest.tsv','hits.tsv'):
        (repaired/n).write_bytes(b'\n'.join((repaired/n).read_bytes().splitlines()[:2])+b'\n')
    rejected(exe,['verify',repaired],2)
    finish(repaired,exe)
    oracle.need((repaired/'hits.tsv').read_bytes()==(baseline/'hits.tsv').read_bytes(),'repair bytes')
    # Forged valid hashes still cannot make an invalid positive pass mathematical replay.
    forged=clone(baseline,'forged')
    state=forged/'s0000000000.tsv'
    raw=state.read_bytes()[:-75]
    hit=raw.splitlines()[-1].split(b'\t')
    hit[-1]=str(int(hit[-1])+1).encode()
    raw=b'\n'.join(raw.splitlines()[:-1]+[b'\t'.join(hit)])+b'\n'
    state.write_bytes(raw+b'state_sha\t'+hashlib.sha256(raw).hexdigest().encode()+b'\n')
    (forged/'s0000000000.sha256').write_text(sha(state)+'\n')
    rejected(exe,['verify',forged])
    kernel_result=kernels()
    return dict(status='PASS',independent_complete_inputs=5098,independent_hits=4,
                independent_misses=5094,**kernel_result,
                interrupted_frontier=frontier,cap_window=[oracle.CAP-3,oracle.CAP],
                scope='bounded disjoint development diagnostics; no new exact index assigned')


def kernels():
    reference=[oracle.witness(4031)]
    count=backend('backend')
    forced=backend('forced',extra=['-DA249107_FORCE_FALLBACK'])
    clang=build('clang',cc='clang-18',flags='-O3 -std=c17 -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wdouble-promotion -Wformat=2 -Werror -fopenmp=libomp',link='-fopenmp=libomp')
    run=init('clang-smoke',2,5000,clang,threads=4)
    oracle.need(finish(run,clang)==reference,'cross compiler')
    sanitizers()
    return dict(backend_observations=count,forced_backend_observations=forced)


def sanitizers():
    reference=[oracle.witness(4031)]
    env=dict(ENV,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',
             UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    sanitizer='-O1 -g -std=c17 -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Werror -fopenmp=libomp -fsanitize=address,undefined -fno-omit-frame-pointer'
    san=build('asan',cc='clang-18',flags=sanitizer,link='-fopenmp=libomp -fsanitize=address,undefined')
    run=init('asan-smoke',2,5000,san,threads=4,env=env)
    oracle.need(finish(run,san,env=env)==reference,'sanitizer oracle')
    backend('asan-backend',cc='clang-18',flags=sanitizer,
            link='-fopenmp=libomp -fsanitize=address,undefined',env=env)
    return dict(sanitizers='ASan/UBSan PASS; LeakSanitizer unavailable under ptrace, disabled',
                sanitizer_environment={k:env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS')})


def main():
    global OUT
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['smoke','matrix','kernels','sanitizers'])
    p.add_argument('output',nargs='?',default='smoke-'+str(time.time_ns()))
    args=p.parse_args()
    oracle.need(Path(args.output).name==args.output,'output must be a basename')
    OUT=ROOT/'validation/local'/args.output
    OUT.mkdir(parents=True,exist_ok=False)
    summary=dict(status='FAIL',source_sha=sha(ROOT/'src/a249107.c'),
                 make_sha=sha(ROOT/'src/Makefile'),binary_sha=sha(ROOT/'src/a249107'),
                 python=sys.version,environment={'OMP_DYNAMIC':ENV['OMP_DYNAMIC']})
    try:
        if args.mode=='matrix':
            summary.update(matrix())
        elif args.mode=='kernels':
            summary.update(kernels(),status='PASS')
        elif args.mode=='sanitizers':
            summary.update(sanitizers(),status='PASS')
        else:
            smoke(ROOT/'src/a249107')
            summary.update(status='PASS',independent_complete_inputs=4999)
    finally:
        (OUT/'events.json').write_text(json.dumps(EVENTS,indent=2)+'\n')
        (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
