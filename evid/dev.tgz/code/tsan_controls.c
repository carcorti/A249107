/* Generic qualification: same barriers, reduction and deadline CAS pattern. */
#include <omp.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
static int shared;
static _Atomic unsigned deadline;
int main(int argc,char **argv) {
    if(argc!=2) return 1;
    if(!strcmp(argv[1],"startup")) { puts("startup"); return 0; }
    if(!strcmp(argv[1],"clean")) {
        int slots[128]={0}; unsigned long total=0;
#pragma omp parallel for num_threads(4) reduction(+:total)
        for(int i=0;i<128;++i) {
            slots[i]=i+1; total+=(unsigned)slots[i];
            unsigned old=atomic_load_explicit(&deadline,memory_order_relaxed);
            while(old<(unsigned)i && !atomic_compare_exchange_weak_explicit(
                &deadline,&old,(unsigned)i,memory_order_relaxed,memory_order_relaxed)) {}
        }
        if(total!=8256 || atomic_load(&deadline)!=127) return 1;
        puts("clean"); return 0;
    }
    if(!strcmp(argv[1],"race")) {
#pragma omp parallel for num_threads(4)
        for(int i=0;i<128;++i) shared+=i+1;
        printf("racy value %d\n",shared); return 0;
    }
    return 1;
}
