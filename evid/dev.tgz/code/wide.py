#!/usr/bin/env python3
"""Native 68-bit fifth derivative and synthetic 69-bit root serialization."""
import json
import sys
sys.dont_write_bytecode=True
import run as h

h.OUT=h.ROOT/'validation/local'/sys.argv[1]
h.OUT.mkdir(exist_ok=False)
summary=dict(status='FAIL',source_sha=h.sha(h.ROOT/'src/a249107.c'),
             make_sha=h.sha(h.ROOT/'src/Makefile'))
try:
    n=2**45
    chain=[n]
    for _ in range(5): chain.append(h.oracle.derivative(chain[-1]))
    h.oracle.need(chain[-1].bit_length()==68 and h.oracle.witness(n) is None,
                  'wide actual negative fixture')
    exe=h.ROOT/'src/a249107'
    run=h.init('actual-wide',n,n,exe)
    h.oracle.need(h.finish(run,exe)==[],'native wide negative')
    backend=h.build('backend',backend=True)
    synthetic=h.OUT/'synthetic'; synthetic.mkdir()
    h.call([backend,'roundtrip',synthetic])
    flags='-O1 -g -std=c17 -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Werror -fopenmp=libomp -fsanitize=address,undefined -fno-omit-frame-pointer'
    env=dict(h.ENV,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',
             UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    san=h.build('asan',cc='clang-18',flags=flags,link='-fopenmp=libomp -fsanitize=address,undefined')
    run=h.init('asan-wide',n,n,san,env=env)
    h.oracle.need(h.finish(run,san,env=env)==[],'sanitized native wide negative')
    backend=h.build('asan-backend',cc='clang-18',flags=flags,
                     link='-fopenmp=libomp -fsanitize=address,undefined',backend=True)
    synthetic=h.OUT/'asan-synthetic'; synthetic.mkdir()
    h.call([backend,'roundtrip',synthetic],env=env)
    summary.update(status='PASS',actual_chain=chain,square_sum_bits=136,
                   synthetic='all coordinate bounds, 69-bit root and UINT64_MAX elapsed_ns roundtrip; no mathematical hit claimed',
                   sanitizers='ASan/UBSan; LeakSanitizer disabled due ptrace environment')
finally:
    (h.OUT/'events.json').write_text(json.dumps(h.EVENTS,indent=2)+'\n')
    (h.OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
