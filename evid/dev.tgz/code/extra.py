#!/usr/bin/env python3
"""Supplemental finite fault, sentinel, binding and MR base-domain probes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
import run as h
import sympy

h.OUT=h.ROOT/'validation/local'/sys.argv[1]
h.OUT.mkdir(exist_ok=False)
exe=h.ROOT/'src/a249107'
summary=dict(status='FAIL',source_sha=h.sha(h.ROOT/'src/a249107.c'),
             make_sha=h.sha(h.ROOT/'src/Makefile'),binary_sha=h.sha(exe))
try:
    backend=h.build('backend',backend=True)
    result=h.call([backend])
    for line in result.stdout.splitlines():
        if line.startswith('D\t'):
            _,n,d,prime=line.split('\t'); n=int(n)
            fs=sympy.factorint(n) if n>=2 else {}
            h.oracle.need(int(d)==sum(int(e)*(n//int(p)) for p,e in fs.items()) and
                          int(prime)==int(sympy.isprime(n)),'backend mismatch')
    h.oracle.need('checkpoint_frontier=4030' in result.stderr and
                  'factor_operand=14089' in result.stderr and
                  'uncommitted_block' in result.stderr,'heartbeat mechanism')
    bases=(2,325,9375,28178,450775,9780504,1795265022)
    divisors=sorted({int(n) for b in bases for n in sympy.divisors(b) if n>=2})
    h.oracle.need(len(divisors)==55,'vanishing-base domain changed')
    for n in divisors:
        p=h.call([backend,'prime',n])
        h.oracle.need(int(p.stdout)==int(sympy.isprime(n)),'vanishing-base primality')
    run=h.init('zero',1701,1701,exe)
    h.oracle.need('checkpoint_frontier=1700' in h.call([exe,'status',run]).stdout,'nonzero sentinel')
    h.rejected(exe,['verify',run],2)
    h.finish(run,exe)
    before={p.name:h.sha(p) for p in run.iterdir() if p.is_file()}
    h.call([exe,'next',run])
    h.oracle.need(before=={p.name:h.sha(p) for p in run.iterdir() if p.is_file()},'idempotent completed next')
    h.init('segments2048',2,2048*16384+1,exe,group=1)
    h.rejected(exe,['init',h.OUT/'segments2049',2,2049*16384+1,16384,1,8])
    for name in ('a249107.c','Makefile'):
        stale=h.OUT/('stale-'+name); stale.mkdir()
        for n in ('a249107.c','Makefile','a249107'):
            shutil.copy2(h.ROOT/'src'/n,stale/n)
        (stale/name).write_bytes((stale/name).read_bytes()+b'\n')
        target=h.OUT/('stale-run-'+name)
        h.rejected(stale/'a249107',['init',target,2,3,16384,1,1])
        h.oracle.need(not target.exists(),'binding refusal had side effects')
    faults=h.OUT/'io_faults.so'
    h.call(['gcc','-O1','-std=gnu17','-Wall','-Wextra','-Werror','-fPIC','-shared',
            h.ROOT/'validation/io_faults.c','-ldl','-o',faults])
    probes=[('fsync',1),('fsync',5),('fsync',7),('fsync',9),('fsync',12),
            ('rename',1),('rename',3),('rename',4),('rename',5),
            ('fflush',1),('fflush',3),('fflush',4)]
    for op,n in probes:
        run=h.init(op+str(n),4031,4031,exe)
        env=dict(h.ENV,LD_PRELOAD=str(faults),A249107_FAULT_OP=op,A249107_FAULT_AT=str(n))
        failed=h.call([exe,'next',run],expected=1,env=env)
        h.oracle.need('ERROR:' in failed.stderr,'fault not surfaced')
        # A late directory-sync failure may leave fully correct sealed bytes;
        # successful recovery is judged from records, never from prior exit alone.
        h.oracle.need(h.finish(run,exe)==[h.oracle.witness(4031)],'fault recovery lost positive')
        h.oracle.need(not any('.tmp.' in p.name for p in run.iterdir()),'stale temp leak')
    full=h.OUT/'fsync1'
    with open('/dev/full','w') as f:
        r=subprocess.run([str(exe),'status',str(full)],stdout=f,stderr=subprocess.PIPE,
                         text=True,env=h.ENV,timeout=20)
    h.EVENTS.append(dict(args=[str(exe),'status',str(full),'stdout=/dev/full'],
                        expected=1,returncode=r.returncode,stderr=r.stderr,stdout=''))
    h.oracle.need(r.returncode==1 and 'flush stdout' in r.stderr,'failed stdout reported success')
    for opt in ([],['-O']):
        h.call([sys.executable,'-B',*opt,h.ROOT/'validation/check.py','--run',full,
                '--low',4031,'--high',4031])
    summary.update(status='PASS',vanishing_base_divisors=len(divisors),
                   io_fault_cases=len(probes),stdout_failure=True,
                   sentinel_states='zero at nonzero start; one; multiple in matrix; completed idempotence',
                   source_and_make_binding='both refused before mkdir',
                   segment_count_boundary=[2048,2049])
finally:
    (h.OUT/'events.json').write_text(json.dumps(h.EVENTS,indent=2)+'\n')
    (h.OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
