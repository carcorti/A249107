#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* Disposable LD_PRELOAD fixture. Injection happens only in a named child. */
static _Atomic unsigned count;
static int fail(const char *operation) {
    const char *op=getenv("A249107_FAULT_OP"), *at=getenv("A249107_FAULT_AT");
    if(!op || !at || strcmp(op,operation)) return 0;
    unsigned n=atomic_fetch_add(&count,1)+1;
    if(n!=strtoul(at,NULL,10)) return 0;
    errno=ENOSPC; return 1;
}
int fsync(int fd) {
    if(fail("fsync")) return -1;
    int (*real)(int)=(int(*)(int))dlsym(RTLD_NEXT,"fsync");
    if(!real) _Exit(99);
    return real(fd);
}
int rename(const char *a,const char *b) {
    if(fail("rename")) return -1;
    int (*real)(const char *,const char *)=(int(*)(const char *,const char *))dlsym(RTLD_NEXT,"rename");
    if(!real) _Exit(99);
    return real(a,b);
}
int fflush(FILE *f) {
    if(fail("fflush")) return EOF;
    int (*real)(FILE *)=(int(*)(FILE *))dlsym(RTLD_NEXT,"fflush");
    if(!real) _Exit(99);
    return real(f);
}
